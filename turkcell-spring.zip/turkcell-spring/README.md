**#Pair4**
#Hande Arslan
#Halef Budanur
#Fuat Hüriyetoğlu
#Baran Büyük
#Ahmet Çetiner
#Elif Nida Karakaş
#Yavuz Selim Özbey 

