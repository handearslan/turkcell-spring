package com.turkcell.spring.workshop.core.exceptions;


public class BusinessException extends RuntimeException{

    public BusinessException(String message) {
        super(message);
    }
}